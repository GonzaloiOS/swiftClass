//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

let a = "Hello"
let b = "World"

let first = a + ", " + b
let second = "\(a), \(b)"
