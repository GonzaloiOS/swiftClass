//
//  Pizza.swift
//  CrearPizza
//
//  Created by Gonzalo on 13/02/16.
//  Copyright © 2016 G. All rights reserved.
//

import Foundation

class Pizza {
    
    var size:String
    var mass:String!
    var cheese:String!
    var ingredients:[String]!
    
    init(size:String){
        
        self.size = size;
    }
}
